<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Absensi;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $id = Auth::user()->id;
        $data = User::findOrFail($id);
        // dd($data);
        $absen = Absensi::whereDay('created_at', date('d'))->where('id_user', $id)->first();

            return view('frontend.index', [
                'data' => $data,
                'absen' => $absen,
            ]);
    }


    public function profil()
    {
        $id = Auth::user()->id;
        $data = User::findOrFail($id);

        return view('frontend.profile', [
            'data' => $data,
        ]);
    }
}
