<?php

return [
    'name' => 'SID BPD BALI',
    'manifest' => [
        'name' => 'DRIVER BPD BALI',
        'short_name' => 'SID',
        'start_url' => '/login',
        'background_color' => '#3367D6',
        'theme_color' => '#000000',
        'display' => 'standalone',
        'orientation'=> 'any',
        'status_bar'=> 'black',
        'icons' => [
            '72x72' => [
                'path' => '/images/icons/72x72.png',
                'purpose' => 'any'
            ],
            '96x96' => [
                'path' => '/images/icons/96x96.png',
                'purpose' => 'any'
            ],
            '128x128' => [
                'path' => '/images/icons/128x128.png',
                'purpose' => 'any'
            ],
            '144x144' => [
                'path' => '/images/icons/144x144.png',
                'purpose' => 'any'
            ],
            '152x152' => [
                'path' => '/images/icons/152x152.png',
                'purpose' => 'any'
            ],
            '192x192' => [
                'path' => '/images/icons/192x192.png',
                'purpose' => 'any'
            ],
            '384x384' => [
                'path' => '/images/icons/384x384.png',
                'purpose' => 'any'
            ],
            '512x512' => [
                'path' => '/images/icons/512x512.png',
                'purpose' => 'any'
            ],
        ],
        'splash' => [
            '640x1136' => '/images/icons/128x128.png',
            '750x1334' => '/images/icons/splash-750x1334.png',
            '828x1792' => '/images/icons/splash-828x1792.png',
            '1125x2436' => '/images/icons/splash-1125x2436.png',
            '1242x2208' => '/images/icons/splash-1242x2208.png',
            '1242x2688' => '/images/icons/splash-1242x2688.png',
            '1536x2048' => '/images/icons/splash-1536x2048.png',
            '1668x2224' => '/images/icons/splash-1668x2224.png',
            '1668x2388' => '/images/icons/splash-1668x2388.png',
            '2048x2732' => '/images/icons/splash-2048x2732.png',
        ],
        'shortcuts' => [
            [
                'name' => 'SID BPD BALI',
                'description' => 'Test',
                'url' => '/login',
                'icons' => [
                    "src" => "/images/icons/96x96.png",
                    "purpose" => "any"
                ]
            ],
            [
                'name' => 'Shortcut Link 2',
                'description' => 'Shortcut Link 2 Description',
                'url' => '/login',
                'icons' => [
                    "src" => "/images/icons/96x96.png",
                    "purpose" => "any"
                ]
            ]
        ],
        'custom' => []
    ]
];
