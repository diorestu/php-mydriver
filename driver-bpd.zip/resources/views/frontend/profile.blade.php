@extends('layouts.frontend')

@section('title')
Dashboard
@endsection

@section('content')
<!-- Header -->
<div class="navbar two-action no-hairline">
    <div class="navbar-inner d-flex align-items-center justify-content-between">
        <div class="left">
            <a href="#" class="link icon-only"><i class="material-icons">menu</i></a>
        </div>
    </div>
</div>
<!-- /Header -->

<!-- Page Content -->
<div class="page-content mt-0">
    <div class="profile-header">
        <form method="POST" action="{{ route('profil.update', $data->id) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="pro-img-box">
                {{-- <img alt="" src="frontend/assets/img/user.jpg"> --}}
                <img alt=""
                    src="{{ ($data->photos == null) ? asset('frontend/assets/img/user.jpg') : asset('storage/'.$data->photos)}}">
                <div class="pro-img-upload">
                    <input type="file" class="upload" name="photos">
                </div>
            </div>
            <div class="pro-user-det">
                <div class="profile-name">
                    <h2>{{ $data->name }}</h2>
                </div>
                <div class="profile-designation">
                    <h6>BPD Bali - {{ ($data->unitkerja == null) ? $data->cabang->cabang : $data->unitkerja->nama }}</h6>
                </div>
            </div>
            <button class="btn btn-info" type="submit">SIMPAN</button>
        </form>
    </div>
</div>

@endsection
