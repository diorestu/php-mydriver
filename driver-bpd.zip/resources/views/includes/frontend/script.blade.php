<!-- Jquery JS -->
    <script type="text/javascript" src="{{ asset('frontend/assets/js/jquery-3.5.0.min.js') }}"></script>

    <!-- Bootstrap Core JS -->
    <script src="{{ asset('frontend/assets/js/popper.min.js') }}"></script>
    <script src="{{ asset('frontend/assets/js/bootstrap.min.js') }}"></script>

    <!-- Chart JS -->
    {{-- <script type="text/javascript" src="{{ asset('frontend/assets/js/Chart.bundle.js') }}"></script> --}}

    <!-- Main JS -->
    <script type="text/javascript" src="{{ asset('frontend/assets/js/script.js') }}"></script>
