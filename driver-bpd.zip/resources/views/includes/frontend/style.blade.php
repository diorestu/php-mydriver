<link rel="stylesheet" href="{{ asset('frontend/assets/css/bootstrap.min.css') }}">

<!-- Font-Awesome CSS -->
<link rel="stylesheet" href="{{ asset('frontend/assets/plugins/css/all.css') }}">
<link rel="stylesheet" href="{{ asset('frontend/assets/plugins/css/fontawesome.min.css') }}">

<!-- Main CSS -->
<link rel="stylesheet" href="{{ asset('frontend/assets/css/style.css') }}">
